<?php
// File: api/send_cpo_email.php
header('Content-Type: application/json');
ini_set('display_errors', 0);
error_reporting(E_ALL);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php'; 

$mail = new PHPMailer(true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method. POST required.']);
    exit;
}

$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$lead_id = isset($_POST['lead_id']) ? trim($_POST['lead_id']) : '';
$quotation_id = isset($_POST['quotation_id']) ? trim($_POST['quotation_id']) : '';

if (empty($email) || empty($quotation_id)) {
    echo json_encode(['success' => false, 'message' => 'Missing required parameters.']);
    exit;
}

// 1. Database Connection
$servername = "15.207.37.132";
$username = "cloud";
$password = "TUCKER_ser_sql";
$dbname = "marketing_new";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed.']);
    exit;
}

// 2. Fetch Line Items from 'productss'
$stmt_items = $conn->prepare("SELECT product_name, unit_price, quantity, total_price FROM productss WHERE quotation_id = ?");
$stmt_items->bind_param("i", $quotation_id);
$stmt_items->execute();
$items_result = $stmt_items->get_result();

$product_rows_html = "";
$subtotal = 0;
while ($item = $items_result->fetch_assoc()) {
    $subtotal += $item['total_price'];
    $product_rows_html .= "
        <tr style='border-bottom: 1px solid #f2f2f2;'>
            <td style='padding: 12px 0; font-size: 13px; color: #111;'>
                <div style='font-weight:bold;'>{$item['product_name']}</div>
            </td>
            <td align='center' style='padding: 12px 0; font-size: 13px;'>{$item['quantity']}</td>
            <td align='right' style='padding: 12px 0; font-size: 13px;'>₹ " . number_format($item['unit_price'], 2) . "</td>
            <td align='right' style='padding: 12px 0; font-size: 13px; font-weight:bold;'>₹ " . number_format($item['total_price'], 2) . "</td>
        </tr>";
}

// 3. Fetch Payment Detail (Mode and Total Received)
$stmt_pay = $conn->prepare("SELECT payment_mode FROM payments WHERE related_id = ? ORDER BY id DESC LIMIT 1");
$stmt_pay->bind_param("i", $quotation_id);
$stmt_pay->execute();
$pay_res = $stmt_pay->get_result()->fetch_assoc();
$pay_mode = $pay_res['payment_mode'] ?? 'N/A';

$paid_query = $conn->query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE related_id = $quotation_id");
$amount_received = (float)$paid_query->fetch_row()[0];
$balance_due = max(0, $subtotal - $amount_received);

// 4. CHECK ACTIVATION STATUS (Hide box if is_used = '1')
$show_activation_box = true;
$cpo_link = "";

$check = $conn->prepare("SELECT is_used, cpo_link FROM cpo_activation_links WHERE lead_id = ?");
$check->bind_param("i", $lead_id);
$check->execute();
$res = $check->get_result();

if ($res->num_rows > 0) {
    $link_data = $res->fetch_assoc();
    if ($link_data['is_used'] == '1') {
        $show_activation_box = false; 
    } else {
        $cpo_link = $link_data['cpo_link'];
    }
}

// Create link if record doesn't exist and link should be shown
if ($show_activation_box && empty($cpo_link)) {
    $token = bin2hex(random_bytes(32));
    $cpo_link = "https://star.tuckermotors.com/TuckerApp/cpo/create_cpo.php?token=" . $token;
    $ins = $conn->prepare("INSERT INTO cpo_activation_links (token, quotation_id, lead_id, created_at, cpo_link, is_used) VALUES (?, ?, ?, NOW(), ?, '0')");
    $ins->bind_param("siis", $token, $quotation_id, $lead_id, $cpo_link);
    $ins->execute();
}
$conn->close();

// 5. Activation Section HTML
$activation_html = "";
if ($show_activation_box) {
    $activation_html = "
    <div style='background-color: #0b0b0b; color: white; border-radius: 12px; padding: 35px; margin-top: 30px; position: relative; overflow: hidden;'>
        <p style='color:#666; font-size:10px; text-transform:uppercase; margin:0; letter-spacing:1px;'>Partner Activation</p>
        <h2 style='margin:10px 0; font-size:22px; color:#ffffff;'>Create your CPO ID</h2>
        <p style='color:#bbb; font-size:13px; line-height:1.6;'>Your Tucker EV CPO partner account is ready for activation. Create your unique ID to configure your branded charging platform.</p>
        <a href='$cpo_link' style='background-color:#E31E24; color:#ffffff; padding:14px 28px; text-decoration:none; border-radius:4px; font-weight:bold; display:inline-block; margin-top:15px; font-size:13px;'> CPO Link →</a>
        <div style='position:absolute; bottom:-30px; right:10px; font-size:100px; font-weight:bold; color:rgba(255,255,255,0.03); font-family: sans-serif;'>WL</div>
    </div>";
}

// 6. Build the Email Template
$primary_red = "#E31E24";
$logo_url = "https://tuckermotors.com/images/logo.png";

$message = "
<!DOCTYPE html>
<html>
<head><meta charset='utf-8'></head>
<body style='font-family: Arial, sans-serif; background-color: #f7f7f7; margin: 0; padding: 0;'>
    <div style='width: 100%; max-width: 600px; margin: 25px auto; background: #ffffff; border-radius: 8px; overflow: hidden; border: 1px solid #eeeeee;'>
        
        <!-- Header -->
        <div style='background-color: #0b0b0b; padding: 25px 35px;'>
            <table width='100%'><tr>
                <td><img src='$logo_url' height='30' alt='Tucker EV Charger'></td>
                <td align='right'><span style='border:1px solid #333; padding:4px 12px; border-radius:20px; font-size:10px; color:#888; text-transform:uppercase; letter-spacing:1px;'>PARTNER NOTICE</span></td>
            </tr></table>
        </div>

        <!-- Success Banner -->
        <div style='background-color: #FFF9F9; border-left: 4px solid $primary_red; padding: 18px 35px; border-bottom: 1px solid #f2f2f2;'>
            <b style='color:$primary_red; font-size:15px;'>✔ Payment Successful</b> <span style='color:#999; font-size:13px; margin-left:10px;'>order confirmed</span>
        </div>

        <div style='padding: 35px;'>
            <p style='color:#999; font-size:11px; text-transform:uppercase; margin:0; letter-spacing:1px;'>Hello, Partner</p>
            <h1 style='margin:10px 0; font-size:28px; font-family: Georgia, serif; color: #111;'>Payment confirmed.</h1>
            <p style='color:#666; font-size:14px; line-height:1.6;'>Thank you for partnering with Tucker EV Charger. We have successfully received your payment. Your order is now queued for processing.</p>

            <!-- Product Table -->
            <p style='font-size:11px; font-weight:bold; color:#999; text-transform:uppercase; margin-top:35px;'>Order Items</p>
            <table width='100%' style='border-collapse:collapse; margin-top:10px;'>
                <tr style='font-size:10px; color:#999; text-transform:uppercase; border-bottom:1px solid #eeeeee;'>
                    <th align='left' style='padding-bottom:10px;'>Product</th>
                    <th align='center' style='padding-bottom:10px;'>Qty</th>
                    <th align='right' style='padding-bottom:10px;'>Unit Price</th>
                    <th align='right' style='padding-bottom:10px;'>Amount</th>
                </tr>
                $product_rows_html
            </table>

            <!-- Financial Breakdown -->
            <div style='background-color: #F9FAFB; border-radius: 8px; padding: 25px; margin-top: 30px;'>
                <table width='100%' style='font-size:14px; border-spacing:0 8px;'>
                    <tr><td style='color:#888;'>Order ID:</td><td align='right'><b>#ORD-WL-$lead_id</b></td></tr>
                    <tr><td style='color:#888;'>Date:</td><td align='right'>" . date('d M Y') . "</td></tr>
                    <tr><td style='color:#888;'>Payment Method:</td><td align='right'>$pay_mode</td></tr>
                    <tr><td colspan='2'><hr style='border:none; border-top:1px solid #e5e5e5; margin:10px 0;'></td></tr>
                    <tr><td><b>Subtotal:</b></td><td align='right'><b>₹ " . number_format($subtotal, 2) . "</b></td></tr>
                    <tr><td style='color:#10B981;'>✔ Amount Received:</td><td align='right' style='color:#10B981; font-weight:bold;'>₹ " . number_format($amount_received, 2) . "</td></tr>
                    <tr>
                        <td style='color:$primary_red; font-size:17px; font-family: Georgia, serif; padding-top:10px;'>Balance Due:</td>
                        <td align='right' style='color:$primary_red; font-size:22px; font-weight:bold; padding-top:10px; font-family: Georgia, serif;'>₹ " . number_format($balance_due, 2) . "</td>
                    </tr>
                </table>
            </div>

            $activation_html

            <p style='text-align:center; font-size:11px; color:#999; margin-top:40px;'>
                For order queries, reach us at <a href='mailto:support@tuckermotors.com' style='color:$primary_red; text-decoration:none;'>support@tuckermotors.com</a>
            </p>
        </div>

        <div style='background-color:#f9f9f9; padding:20px; text-align:center; border-top:1px solid #eee; font-size:11px; color:#999;'>
            Tucker Motors Private Limited • Privacy Policy • Terms
        </div>
    </div>
</body>
</html>";

// 7. Send Email
try {
    $mail->isSMTP();
    $mail->Host       = 'vps.hul-brupack.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'support@tuckermotors.com';
    $mail->Password   = 'SUP@rt1000'; 
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;
    $mail->CharSet    = 'UTF-8';

    $mail->setFrom('support@tuckermotors.com', 'Tucker Motors');
    $mail->addAddress($email);
    $mail->isHTML(true);
    $mail->Subject = "Payment Receipt: Order #ORD-WL-$lead_id Confirmed";
    $mail->Body    = $message;

    $mail->send();
    echo json_encode(['success' => true, 'message' => 'Branded email sent successfully.']);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Mailer Error: ' . $mail->ErrorInfo]);
}